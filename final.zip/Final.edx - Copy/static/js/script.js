/**
 * BudgetBuddy - Client-side JavaScript
 * Manages category filtering based on transaction type and initializes Chart.js charts.
 *
 * Citation: Authored with assistance from AI tools for Harvard CS50x final project.
 */

function filterCategories() {
    const typeSelect = document.getElementById('typeSelect');
    const categorySelect = document.getElementById('categorySelect');
    if (!typeSelect || !categorySelect) return;

    const selectedType = typeSelect.value;
    const options = categorySelect.querySelectorAll('option');

    let firstMatch = null;
    options.forEach(option => {
        const optionType = option.getAttribute('data-type');
        const shouldShow = (optionType === selectedType);
        option.style.display = shouldShow ? '' : 'none';
        if (shouldShow && !firstMatch) {
            firstMatch = option;
        }
    });

    // If currently selected option is hidden, change selection to the first valid visible option
    const currentOption = categorySelect.options[categorySelect.selectedIndex];
    if (currentOption && currentOption.style.display === 'none' && firstMatch) {
        categorySelect.value = firstMatch.value;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // Run category filtering immediately on page load
    if (document.getElementById('typeSelect') && document.getElementById('categorySelect')) {
        filterCategories();
    }

    // Initialize Category Spending Chart (Doughnut)
    if (typeof categoryData !== 'undefined' && Array.isArray(categoryData) && categoryData.length > 0) {
        const ctx = document.getElementById('categoryChart');
        if (ctx) {
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: categoryData.map(c => `${c.icon} ${c.name}`),
                    datasets: [{
                        data: categoryData.map(c => c.total),
                        backgroundColor: [
                            '#22c55e', '#3b82f6', '#f59e0b', '#ec4899',
                            '#8b5cf6', '#06b6d4', '#10b981', '#f97316',
                            '#6366f1', '#14b8a6', '#ef4444', '#84cc16'
                        ],
                        borderWidth: 2,
                        borderColor: '#212529'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                color: '#adb5bd',
                                boxWidth: 12,
                                padding: 10,
                                font: { size: 12 }
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return ` ${context.label}: ${context.raw.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
                                }
                            }
                        }
                    }
                }
            });
        }
    }

    // Initialize Daily Spending Chart (Line)
    if (typeof dailyData !== 'undefined' && Array.isArray(dailyData) && dailyData.length > 0) {
        const ctx = document.getElementById('dailyChart');
        if (ctx) {
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: dailyData.map(d => d.date.slice(5)),
                    datasets: [{
                        label: 'Daily Spending',
                        data: dailyData.map(d => d.total),
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.2)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.35,
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    },
                    scales: {
                        x: {
                            grid: { color: 'rgba(255, 255, 255, 0.08)' },
                            ticks: { color: '#adb5bd' }
                        },
                        y: {
                            beginAtZero: true,
                            grid: { color: 'rgba(255, 255, 255, 0.08)' },
                            ticks: { color: '#adb5bd' }
                        }
                    }
                }
            });
        }
    }
});
